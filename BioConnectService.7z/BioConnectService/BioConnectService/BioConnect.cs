﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Net;
using System.Net.Sockets; 


namespace BioConnectService
{
    public partial class BioConnect : ServiceBase
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Diagnostics.EventLog eventLog;

        private TCPServer server = null;

        //public static ManualResetEvent tcpClientConnected = new ManualResetEvent(false);

        public BioConnect()
        {
            InitializeComponent();

            //define custom event log
            eventLog = new System.Diagnostics.EventLog();
            if (!System.Diagnostics.EventLog.SourceExists("BioSource"))
            {
                System.Diagnostics.EventLog.CreateEventSource("BioSource", "BioLog");
            }

            eventLog.Source = "BioSource";
            eventLog.Log = "BioLog";

        }

        internal void TestStartupAndStop(string[] args)
        {
            this.OnStart(args);
            Console.ReadLine();
            this.OnStop();
        }

        /// <summary>
        /// OnStart
        /// </summary>
        /// <param name="args"></param>
        protected override void OnStart(string[] args)
        {

          eventLog.WriteEntry("In OnStart");
          try
          {
              // Create the Server Object ans Start it.
              server = new TCPServer();
              server.StartServer();

          }
          catch (SocketException e)
          {
              eventLog.WriteEntry(string.Format("SocketException: {0}", e.Message));
          }
          finally
          {
          }


//////////////////////////////////////////////////////////////////////////////////
            //int COUNT = 0;
            //int CONNECTIONS = 0;
            //int PRIME = 0;

            //TcpListener listener = null;
            //try
            //{
            //    // Set the TcpListener on port 55555.
            //    Int32 port = 55555;
            //    IPAddress localAddr = IPAddress.Parse("127.0.0.1");
            //    // TcpListener listener = new TcpListener(port);
            //    listener = new TcpListener(localAddr, port);
            //    // Start listening for client requests.
            //    listener.Start();
            //    // Buffer for reading data
            //    Byte[] bytes = new Byte[256];
            //    String data = null;
            //    // Enter the listening loop.
            //    //while (true)
            //    //{
            //        // Perform a blocking call to accept requests.
            //        // You could also user listener.AcceptSocket() here.
            //        TcpClient client = listener.AcceptTcpClient();
            //        eventLog.WriteEntry("Connected...");
            //        CONNECTIONS++;
            //        data = null;
            //        // Get a stream object for reading and writing
            //        NetworkStream stream = client.GetStream();
            //        int i;
            //        // Loop to receive all the data sent by the client.
            //        while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
            //        {
            //            byte[] msg = System.Text.Encoding.ASCII.GetBytes("N/A"); 
            //            // Translate data bytes to a ASCII string.
            //            data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
            //            eventLog.WriteEntry(string.Format("Received: {0}", data));
            //            // Process the data sent by the client.
            //            data = data.ToUpper();
            //            switch(data){
            //                case "HELLO":
            //                    msg = System.Text.Encoding.ASCII.GetBytes("HI");
            //                    break;
            //                case "COUNT":
            //                    COUNT++;
            //                    msg = System.Text.Encoding.ASCII.GetBytes(COUNT.ToString());
            //                    break;
            //                case "CONNECTIONS":
            //                    msg = System.Text.Encoding.ASCII.GetBytes(CONNECTIONS.ToString());
            //                    break;
            //                case "PRIME":
            //                    msg = System.Text.Encoding.ASCII.GetBytes(PRIME.ToString());
            //                    break;
            //                case "TERMINATE":
            //                    client.Close();// Shutdown and end connection
            //                    CONNECTIONS--;
            //                    break;
            //                default:
            //                    break;
            //            }
            //            //byte[] msg = System.Text.Encoding.ASCII.GetBytes(data);
            //            // Send back a response.
            //            stream.Write(msg, 0, msg.Length);
            //            eventLog.WriteEntry(string.Format("Sent back: {0}", data));
            //        }
            //    //}
            //}
            //catch (SocketException e)
            //{
            //    eventLog.WriteEntry(string.Format("SocketException: {0}", e.Message));
            //}
            //finally
            //{
            //    // Stop listening for new clients.
            //    listener.Stop();
            //}

        }

        /// <summary>
        /// OnStop
        /// </summary>
        protected override void OnStop()
        {
            eventLog.WriteEntry("In OnStop");
            // Stop the Server. Release it.
            server.StopServer();
            server = null;
        }

        /// <summary>
        /// OnContinue
        /// </summary>
        protected override void OnContinue()
        {
            eventLog.WriteEntry("In OnContinue.");
        }
    }
}



