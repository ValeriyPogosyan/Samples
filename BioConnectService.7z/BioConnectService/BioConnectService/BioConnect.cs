﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Net;
using System.Net.Sockets;


namespace BioConnectService
{
    public partial class BioConnect : ServiceBase
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Diagnostics.EventLog eventLog;

        private TCPServer server = null;

        public BioConnect()
        {
            InitializeComponent();

            //define custom event log
            eventLog = new System.Diagnostics.EventLog();
            if (!System.Diagnostics.EventLog.SourceExists("BioSource"))
            {
                System.Diagnostics.EventLog.CreateEventSource("BioSource", "BioLog");
            }

            eventLog.Source = "BioSource";
            eventLog.Log = "BioLog";

        }

        internal void TestStartupAndStop(string[] args)
        {
            this.OnStart(args);
            Console.ReadLine();
            this.OnStop();
        }

        /// <summary>
        /// OnStart
        /// </summary>
        /// <param name="args"></param>
        protected override void OnStart(string[] args)
        {

            eventLog.WriteEntry("In OnStart");
            try
            {
                // Create the Server Object ans Start it.
                server = new TCPServer();
                server.StartServer();

            }
            catch (SocketException e)
            {
                eventLog.WriteEntry(string.Format("SocketException: {0}", e.Message));
            }
            finally
            {
            }

        }

        /// <summary>
        /// OnStop
        /// </summary>
        protected override void OnStop()
        {
            eventLog.WriteEntry("In OnStop");
            // Stop the Server. Release it.
            server.StopServer();
            server = null;
        }

        /// <summary>
        /// OnContinue
        /// </summary>
        protected override void OnContinue()
        {
            eventLog.WriteEntry("In OnContinue.");
        }
    }
}



