using System;
using System.Collections;
using System.Net.Sockets;
using System.Threading;
using System.Text;
using System.IO;
using System.Net.NetworkInformation;

namespace BioConnectService
{
    /// <summary>
    /// Summary description for TCPSocketListener.
    /// </summary>
    public class TCPSocketListener
    {
        /// <summary>
        /// Variables that are accessed by other classes indirectly.
        /// </summary>
        private Socket m_clientSocket = null;
        private bool m_stopClient = false;
        private Thread m_clientListenerThread = null;
        private bool m_markedForDeletion = false;

        /// <summary>
        /// Working Variables.
        /// </summary>
        private DateTime m_lastReceiveDateTime;
        private DateTime m_currentReceiveDateTime;

        static int COUNT = 0;

        /// <summary>
        /// Client Socket Listener Constructor.
        /// </summary>
        /// <param name="clientSocket"></param>
        public TCPSocketListener(Socket clientSocket)
        {
            m_clientSocket = clientSocket;
        }

        /// <summary>
        /// Client SocketListener Destructor.
        /// </summary>
        ~TCPSocketListener()
        {
            StopSocketListener();
        }

        /// <summary>
        /// Method that starts SocketListener Thread.
        /// </summary>
        public void StartSocketListener()
        {
            if (m_clientSocket != null)
            {
                m_clientListenerThread = new Thread(new ThreadStart(SocketListenerThreadStart));

                m_clientListenerThread.Start();
            }
        }

        /// <summary>
        /// Thread method that does the communication to the client. This 
        /// thread tries to receive from client and if client sends any data
        /// then parses it and again wait for the client data to come in a
        /// loop. The receive is an indefinite time receive.
        /// </summary>
        private void SocketListenerThreadStart()
        {
            int size = 0;
            Byte[] byteBuffer = new Byte[1024];

            m_lastReceiveDateTime = DateTime.Now;
            m_currentReceiveDateTime = DateTime.Now;

            Timer t = new Timer(new TimerCallback(CheckClientCommInterval), null, 15000, 15000);

            while (!m_stopClient)
            {
                try
                {
                    size = m_clientSocket.Receive(byteBuffer);
                    m_currentReceiveDateTime = DateTime.Now;
                    ParseReceivedBuffer(byteBuffer, size);
                }
                catch (SocketException se)
                {
                    m_stopClient = true;
                    m_markedForDeletion = true;
                }
            }
            t.Change(Timeout.Infinite, Timeout.Infinite);
            t = null;
        }

        /// <summary>
        /// Method that stops Client SocketListening Thread.
        /// </summary>
        public void StopSocketListener()
        {
            if (m_clientSocket != null)
            {
                m_stopClient = true;
                m_clientSocket.Close();

                // Wait for one second for the the thread to stop.
                m_clientListenerThread.Join(1000);

                // If still alive; Get rid of the thread.
                if (m_clientListenerThread.IsAlive)
                {
                    m_clientListenerThread.Abort();
                }
                m_clientListenerThread = null;
                m_clientSocket = null;
                m_markedForDeletion = true;
            }
        }

        /// <summary>
        /// Method that returns the state of this object i.e. whether this
        /// object is marked for deletion or not.
        /// </summary>
        /// <returns></returns>
        public bool IsMarkedForDeletion()
        {
            return m_markedForDeletion;
        }

        /// <summary>
        /// This method parses data that is sent by a client using TCP/IP.
        /// </summary>
        /// <param name="byteBuffer"></param>
        /// <param name="size"></param>
        private void ParseReceivedBuffer(Byte[] byteBuffer, int size)
        {
            byte[] msg = System.Text.Encoding.ASCII.GetBytes("N/A");
            try
            {
                string data = Encoding.ASCII.GetString(byteBuffer, 0, size);
                data = data.ToUpper();
                switch (data)
                {
                    case "HELLO":
                        msg = System.Text.Encoding.ASCII.GetBytes("HI");
                        COUNT++;
                        break;
                    case "COUNT":
                        msg = System.Text.Encoding.ASCII.GetBytes(COUNT.ToString());
                        break;
                    case "CONNECTIONS":
                        IPGlobalProperties properties = IPGlobalProperties.GetIPGlobalProperties();
                        TcpConnectionInformation[] connections = properties.GetActiveTcpConnections();
                        int counter = 0;
                        foreach (TcpConnectionInformation c in connections)
                        {
                            if (c.LocalEndPoint.ToString().Contains("127.0.0.1:55555"))// TODO: replace the address/port with a parameter
                            {
                                counter++;
                            }
#if DEBUG
                            Console.WriteLine("{0} <==> {1}", c.LocalEndPoint.ToString(), c.RemoteEndPoint.ToString());
#endif
                        }
                        msg = System.Text.Encoding.ASCII.GetBytes(counter.ToString());
                        break;
                    case "PRIME":
                        var pn = generatePrimes(1);// for now call a fake method to generate a prime number
                        msg = System.Text.Encoding.ASCII.GetBytes(pn[0].ToString());
                        break;
                    case "TERMINATE":
                        msg = System.Text.Encoding.ASCII.GetBytes("BYE");
                        m_stopClient = true;
                        break;
                    default:
                        break;
                }

                m_clientSocket.Send(msg);
            }
            catch {
                StopSocketListener();//something went wrong...
            
            }
        }

        /// <summary>
        /// Method that checks whether there are any client calls for the
        /// last 15 seconds or not. If not this client SocketListener will
        /// be closed.
        /// </summary>
        /// <param name="o"></param>
        private void CheckClientCommInterval(object o)
        {
            if (m_lastReceiveDateTime.Equals(m_currentReceiveDateTime))
            {
                this.StopSocketListener();
            }
            else
            {
                m_lastReceiveDateTime = m_currentReceiveDateTime;
            }
        }

        /// <summary>
        /// A fake prime numbers generator. TODO: replace with a real one.
        /// </summary>
        /// <param name="numberToGenerate"></param>
        /// <returns></returns>
        ArrayList generatePrimes(int numberToGenerate)
        {
            ArrayList result = new ArrayList();

            result.Add(2);
            result.Add(3);

            for (int i = 5; result.Count <= numberToGenerate; i += 2)
            {
                bool prime = true;
                for (int j = 2; j < Math.Sqrt(i); j++)
                {
                    if (i % j == 0)
                    {
                        prime = false;
                        break;
                    }
                }
                if (prime) result.Add(i);
            }

            return result;
        }

    }
}
