﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;

namespace BioConnectService
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// The BioConnectService service can run as a console app if invoked via
        /// debug mode in VS as well as a regular windows service 
        /// </summary>
        static void Main(string[] args)
        {
            if (Environment.UserInteractive)
            {
                BioConnect service = new BioConnect();
                service.TestStartupAndStop(args);
            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] 
                { 
                    new BioConnect()
                };
                ServiceBase.Run(ServicesToRun);
            }
        }
    }
}


